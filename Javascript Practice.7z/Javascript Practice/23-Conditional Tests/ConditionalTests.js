let mobile = 'IPhone 13 pro';
console.log("Is mobile == 'IPhone 13 pro'? I predict True.")
console.log(mobile == 'IPhone 13 pro')

let bike = 'Honda 150F';
console.log("Is bike == 'Honda 150F'? I predict True.")
console.log(bike == 'Honda 150F')

let car = 'Proche';
console.log("Is car == 'Proche'? I predict True.")
console.log(car == 'Proche')

let hobby = 'Cricket';
console.log("Is Hobby == 'Cricket'? I predict True.")
console.log(hobby == 'Cricket')

let favFood = 'Mutton Champ';
console.log("Is favFood = 'Mutton Champ' ? I predict True.")
console.log(favFood == 'Mutton Champ')

//Wrong Predictions
let favSnack = 'Fries';
console.log("Is favSnack = 'Nuggets'? I predict False.")
console.log(favSnack == 'Nuggets')

let FavSweet = 'Savaiyaan';
console.log("Is FavSweet = 'Custurd'? I predict False.")
console.log(mobile == 'Custurd')

let nativeLanguage = 'Urdu';
console.log("Is nativeLanguage != 'Urdu'? I predict False.")
console.log(nativeLanguage != 'Urdu')

let religion = 'Islam';
console.log("Is religion = 'Hindu'? I predict False.")
console.log(religion == 'Hindu')

let education = 'MSCS';
console.log("Is education = 'MBA'? I predict False.")
console.log(education = 'MBA')
