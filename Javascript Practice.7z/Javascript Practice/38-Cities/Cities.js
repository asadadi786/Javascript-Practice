let country = 'Pakistan'
function describe_city(city,cityCountry)
{
    console.log(city+' is in '+cityCountry+ '.')
}

describe_city('karachi',country)
describe_city('Lahore',country)
describe_city('Istambul','Turkey')