const names = ['Sufi Shemsher Ali', 'Hussain', 'Ilyas','Komal','Zeshan','Naveed','Hassan','Saqib','Waleed','Umer Farooq','Arsalan']

names.forEach(printNamesWithGreetings)

function printNamesWithGreetings(namesWithGreetingsVal, index, array)
{
    console.log("Hello " + namesWithGreetingsVal+ ", Weloce to PanaVerse.")
}