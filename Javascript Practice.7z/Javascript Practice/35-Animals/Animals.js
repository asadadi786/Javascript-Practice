const animals = ['cat','dog','goat']

for(let i=0;i< animals.length;i++)
{
    console.log(animals[i])

    console.log('A ' +animals[i]+ ' would make a great pet.')

}

console.log('Any of these animals '+animals[0]+ ',' +animals[1]+',' +animals[2]+ ' would make a great pet!.')