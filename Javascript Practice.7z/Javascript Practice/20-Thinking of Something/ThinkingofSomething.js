var something = ['Suadia Arabia','Pakistan','Turkey','America','Canada','China','Singapore']

something.forEach(printSomething)

function printSomething(value,index,array)
{
    console.log(value)
}