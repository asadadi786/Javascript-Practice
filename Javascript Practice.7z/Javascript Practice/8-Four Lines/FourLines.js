var num = 8;
const line = '-'.repeat(process.stdout.columns)
console.log(line );
console.log(num)
console.log(line)
console.log(num)
console.log(line)
console.log(num)
console.log(line)
console.log(num)
console.log(line)