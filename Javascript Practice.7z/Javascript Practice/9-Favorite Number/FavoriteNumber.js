var favNum = 155
 
console.log("Favorite Number = " + favNum)