//Muhammad Asad Ilyas
//04 October 2022

//below code displays my favorite number
var favNum = 155
console.log("Favorite Number = " + favNum)

//Below code print out qoute along with name of our beloved PROPHET P.B.U.H.
var famous_person = 'Prophet Muhammad P.B.U.H'
var message = 'Do not wish to be like anyone except in two cases. The first is a person, whom Allah has given wealth & he spends it righteously; (the second is) the one whom Allah has given wisdom (the Holy Quran) and he acts according to it and teaches it to others.'


console.log(famous_person + ' said, "' + message + '"')