const favPizzas = ['bar bq','fajita','pepperoni']

for(let i=0;i< favPizzas.length;i++)
{
    console.log(favPizzas[i])

    console.log('I like ' +favPizzas[i]+ ' pizza.')

}

console.log('I love ' +favPizzas[1]+ ' pizza the most because it is very balanced in taste.\n'+favPizzas[1]+ ' pizza include my favorite ingredents.\nThe deliciousness of '+favPizzas[1]+ ' pizza get doubled with extra cheese and little hard crust.')

console.log('I really love pizza!.')