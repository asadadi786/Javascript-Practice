var guestList = ['Quaid-e-Azam', 'Imran Khan', 'Shoaib Akhtar', 'Elon Mask', 'Edhi Sattar']

guestList.forEach(guestDinnerInvitation)

function guestDinnerInvitation(value,index,array){
    console.log('Hi, ' +value+ '. We are gladly inviting you to join us this weekend as we plan to arrange a delicious dinner party.')
}

