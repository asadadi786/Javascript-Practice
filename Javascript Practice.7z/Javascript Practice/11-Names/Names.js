const names = ['Sufi Shemsher Ali', 'Hussain', 'Ilyas','Komal','Zeshan','Naveed','Hassan','Saqib','Waleed','Umer Farooq','Arsalan']

names.forEach(printNames);

function printNames(fNames, index, array){
    console.log(fNames)
}