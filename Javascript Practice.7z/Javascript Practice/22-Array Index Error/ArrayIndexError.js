var guestList = ['Quaid-e-Azam', 'Imran Khan', 'Shoaib Akhtar', 'Elon Mask', 'Edhi Sattar']

console.log(guestList[5])