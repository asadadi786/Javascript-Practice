var person_name = '     Muhammad\tAsad \nIlyas   '
console.log(person_name)

console.log(person_name.trim())