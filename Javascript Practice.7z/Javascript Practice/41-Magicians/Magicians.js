let magicianList = ['JAY MARSHALL','MAX MAVEN','Rangbaz','Hamoon Jadogar','Muhammad Yaseen']


function show_magicians(magicianListArray)
{
    for(let i=0;i<magicianList.length;i++)
    {
        console.log('Magician Name = ' +magicianListArray[i])
    }
}


show_magicians(magicianList)