var num1 = 4;
var num2 = 4;

add = 5 + 3;
console.log(add);
 
//subtraction
sub = 12 - 4;
console.log(sub);

//multiplication
mul = 4 * 2;
console.log(mul);

//division
div = 16 / 2;
console.log(div);