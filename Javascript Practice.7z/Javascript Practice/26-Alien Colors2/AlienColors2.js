//Runs the if block
let alien_color = 'green';

if(alien_color == 'green')
{
    console.log('The player just earned 5 points for shooting the alien.')
}
else
{
    console.log('The player just earned 10 points.')

}


//Version that runs else statement
alien_color = 'yellow';

if(alien_color == 'green')
{
    console.log('The player just earned 5 points for shooting the alien.')
}
else
{
    console.log('The player just earned 10 points.')

}
