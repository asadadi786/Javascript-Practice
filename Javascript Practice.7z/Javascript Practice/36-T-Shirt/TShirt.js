function make_shirt(size,message)
{
    console.log('The size of the shirt is ' +size+ ' and the message printed on it is ' +message+ '.')
}

make_shirt('medium','Sky is the Limit!')