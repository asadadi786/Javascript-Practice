var famous_person = 'Prophet Muhammad P.B.U.H'
var message = 'Do not wish to be like anyone except in two cases. The first is a person, whom Allah has given wealth & he spends it righteously; (the second is) the one whom Allah has given wisdom (the Holy Quran) and he acts according to it and teaches it to others.'


console.log(famous_person + ' said, "' + message + '"')